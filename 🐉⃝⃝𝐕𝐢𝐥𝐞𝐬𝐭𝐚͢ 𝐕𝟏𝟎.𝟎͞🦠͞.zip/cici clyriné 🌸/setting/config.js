const fs = require('fs')

global.owner = "https://whatsapp.com/channel/0029Vb6nbYY9xVJpD5lB1T32" //owner number
global.footer = "pfft" //footer section
global.status = true //"self/public" section of the bot

global.cicitzyBug = "whatsapp.com/channel/0029Vb6nbYY9xVJpD5lB1T32"

global.lol = "";
global.mess = {
    owner: "lu bukan owner pantek"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})